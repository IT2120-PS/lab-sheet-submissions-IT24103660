#2 
X <- c(1, 15)
sum( X %% 3 == 0)

#3 
Y <- c(3, 7, 2, 9, 5)

max_val <- Y[1]
max_index <- 1

for (i in 2:length(Y)) {
  if (Y[i] > max_val) {
    max_val <- Y[i]
    max_index <- i
  }
}
print(max_index)

#4
max_index <- which.max(Y)
print(max_index)
