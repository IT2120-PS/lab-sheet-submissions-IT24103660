#Exercise
#1 
a <- 10
b <- 3

#2
a + b
a%/%b
a%%b
a^b

#3
isTRUE(a>b)
isTRUE(b==a)
isTRUE(a>5  | b < 2)

#4
scores <- c(85, 90, 78, 92, NA, 88)
class(scores)

mean(scores, na.rm = TRUE)

scores[scores > 85]

#5
student_names <- c("Alice", "Bob", "Charlie", "Diana", "Evan", "Fiona")
scores <- c(85, 78, 92, 60, 88, 74)
passed <- scores >= 80

#6
results <- data.frame(Name = student_names, Score = scores, Passed = passed)
  
# Step 7
str(results)
print(results)

# Step 8
max_score <- max(results$Score, na.rm = TRUE)
max_score


