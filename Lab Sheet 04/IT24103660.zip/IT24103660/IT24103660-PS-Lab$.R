setwd("C://Users//IT24103660//Desktop//IT24103660")
branch_data<-read.table("Exercise.txt",header = TRUE,sep=",")
str(branch_data)
fix(branch_data)
boxplot(X1,
        main = "Boxplot for Sales",
        outline = TRUE,
        outpch = 8,
        horizontal = TRUE)
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)
check_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  return(x[x<lower | x>upper])
}
check_outliers(branch_data$Years_X3)
